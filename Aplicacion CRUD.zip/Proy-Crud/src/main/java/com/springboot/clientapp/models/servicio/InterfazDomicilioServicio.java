package com.springboot.clientapp.models.servicio;

import java.util.List;

import com.springboot.clientapp.models.entidad.Domicilio;

public interface InterfazDomicilioServicio {
	
	List<Domicilio> listaDomicilio(); 
}
