package com.example.proyectocrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoCrudApplication.class, args);
	}

}
